//
//  ViewController.swift
//  networkingDemo
//
//  Created by Oleh Sannikov on 29.01.15.
//  Copyright (c) 2015 Oleh Sannikov. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var imageURL: UITextField!
    
    @IBAction func requestNetworkData(sender: AnyObject) {
        var urlString = imageURL.text
        //let url = NSURL(string:"http://www.clareflorist.co.uk/ProdImages/flowers/white-rosmeria-bouquet-1.jpg")
        let url = NSURL(string:urlString)
        var err: NSError?
        var imageData :NSData = NSData(contentsOfURL:url!,options: NSDataReadingOptions.DataReadingMappedIfSafe, error: &err)!
        imageView.image = UIImage(data:imageData)
        imageURL.text = ""
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}